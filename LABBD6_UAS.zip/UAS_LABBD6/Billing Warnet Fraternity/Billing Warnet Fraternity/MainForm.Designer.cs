﻿/*
 * Created by SharpDevelop.
 * User: LENOVO
 * Date: 12/21/2022
 * Time: 5:11 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Billing_Warnet_Fraternity
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.dataGridView = new System.Windows.Forms.DataGridView();
			this.com = new System.Windows.Forms.TextBox();
			this.paket = new System.Windows.Forms.TextBox();
			this.cuan = new System.Windows.Forms.TextBox();
			this.btnTambah = new System.Windows.Forms.Button();
			this.btnHapus = new System.Windows.Forms.Button();
			this.btnUbah = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.nama = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGridView
			// 
			this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView.Location = new System.Drawing.Point(0, -1);
			this.dataGridView.Name = "dataGridView";
			this.dataGridView.ReadOnly = true;
			this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataGridView.Size = new System.Drawing.Size(411, 519);
			this.dataGridView.TabIndex = 0;
			// 
			// com
			// 
			this.com.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.com.Location = new System.Drawing.Point(494, 78);
			this.com.Name = "com";
			this.com.Size = new System.Drawing.Size(265, 26);
			this.com.TabIndex = 4;
			// 
			// paket
			// 
			this.paket.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.paket.Location = new System.Drawing.Point(494, 119);
			this.paket.Name = "paket";
			this.paket.Size = new System.Drawing.Size(265, 26);
			this.paket.TabIndex = 5;
			// 
			// cuan
			// 
			this.cuan.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cuan.Location = new System.Drawing.Point(494, 161);
			this.cuan.Name = "cuan";
			this.cuan.Size = new System.Drawing.Size(265, 26);
			this.cuan.TabIndex = 6;
			// 
			// btnTambah
			// 
			this.btnTambah.Location = new System.Drawing.Point(417, 220);
			this.btnTambah.Name = "btnTambah";
			this.btnTambah.Size = new System.Drawing.Size(118, 45);
			this.btnTambah.TabIndex = 7;
			this.btnTambah.Text = "Tambah";
			this.btnTambah.UseVisualStyleBackColor = true;
			this.btnTambah.Click += new System.EventHandler(this.BtnTambahClick);
			// 
			// btnHapus
			// 
			this.btnHapus.Location = new System.Drawing.Point(530, 271);
			this.btnHapus.Name = "btnHapus";
			this.btnHapus.Size = new System.Drawing.Size(118, 45);
			this.btnHapus.TabIndex = 8;
			this.btnHapus.Text = "Hapus";
			this.btnHapus.UseVisualStyleBackColor = true;
			this.btnHapus.Click += new System.EventHandler(this.BtnHapusClick);
			// 
			// btnUbah
			// 
			this.btnUbah.Location = new System.Drawing.Point(641, 220);
			this.btnUbah.Name = "btnUbah";
			this.btnUbah.Size = new System.Drawing.Size(118, 45);
			this.btnUbah.TabIndex = 9;
			this.btnUbah.Text = "Ubah";
			this.btnUbah.UseVisualStyleBackColor = true;
			this.btnUbah.Click += new System.EventHandler(this.BtnUbahClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(417, 337);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(359, 181);
			this.pictureBox1.TabIndex = 11;
			this.pictureBox1.TabStop = false;
			// 
			// nama
			// 
			this.nama.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.nama.Location = new System.Drawing.Point(494, 35);
			this.nama.Name = "nama";
			this.nama.Size = new System.Drawing.Size(265, 26);
			this.nama.TabIndex = 13;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(417, 36);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 23);
			this.label1.TabIndex = 14;
			this.label1.Text = "Nama";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(417, 79);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(71, 23);
			this.label2.TabIndex = 15;
			this.label2.Text = "COM";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(417, 120);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(71, 23);
			this.label3.TabIndex = 16;
			this.label3.Text = "Paket";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(417, 162);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(71, 23);
			this.label4.TabIndex = 17;
			this.label4.Text = "Cuan";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.ClientSize = new System.Drawing.Size(771, 514);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.nama);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.btnUbah);
			this.Controls.Add(this.btnHapus);
			this.Controls.Add(this.btnTambah);
			this.Controls.Add(this.cuan);
			this.Controls.Add(this.paket);
			this.Controls.Add(this.com);
			this.Controls.Add(this.dataGridView);
			this.Name = "MainForm";
			this.Text = "bill warnet";
			((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox nama;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnUbah;
		private System.Windows.Forms.Button btnHapus;
		private System.Windows.Forms.Button btnTambah;
		private System.Windows.Forms.TextBox cuan;
		private System.Windows.Forms.TextBox paket;
		private System.Windows.Forms.TextBox com;
		private System.Windows.Forms.DataGridView dataGridView;
	}
}
