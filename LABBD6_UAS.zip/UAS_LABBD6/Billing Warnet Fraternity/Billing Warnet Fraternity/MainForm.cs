﻿/*
 * Created by SharpDevelop.
 * User: LENOVO
 * Date: 12/21/2022
 * Time: 5:11 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.OleDb;

namespace Billing_Warnet_Fraternity
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		MySqlConnection co = new MySqlConnection("Server = localhost; Database = warneta;Uid= root");
		MySqlCommand mycommand = new MySqlCommand();
		MySqlDataAdapter myadapter = new MySqlDataAdapter();
		
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			readdata();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		public void readdata(){
			try{
				mycommand.Connection = co;
				myadapter.SelectCommand = mycommand;
				mycommand.CommandText = "select * from billing";
				DataSet ds= new DataSet();
				if (myadapter.Fill(ds,"dftpesan")>0){
					dataGridView.DataSource = ds;
					dataGridView.DataMember = "dftpesan";
				}
				co.Close();
				}
			catch (Exception ex) {
				MessageBox.Show(ex.ToString());
			}
		}
		
		public void InsertData(){
			try{
				co.Open();
				mycommand.Connection=co;
				mycommand.CommandText="insert into billing values('"+nama.Text+"','"+com.Text+"','"+paket.Text+"'.'"+cuan.Text+"')";
				myadapter.SelectCommand= mycommand;
				if (mycommand.ExecuteNonQuery()==1){
				    	MessageBox.Show("Data Berhasil dimasukkan","Informasi",MessageBoxButtons.OK,MessageBoxIcon.Information);
				    	readdata();
				    }
				    co.Close();
			}
			catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}
		}
		
		public void updateData(){
			try{
				co.Open();
				mycommand.CommandText = "Update billing set Nama='"+nama.Text+"',COM='"+com.Text+"',Paket='"+paket.Text+"',Cuan='"+cuan.Text+"' where Nama ='"+nama.Text+"'";
				myadapter.SelectCommand = mycommand;
				if (mycommand.ExecuteNonQuery()==1){
					MessageBox.Show("Data berhasil di update","Informasi",MessageBoxButtons.OK,MessageBoxIcon.Information);
					readdata();
				}
				co.Close();
			}
			catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}
		}
		
		
		public void deleteData(){
			try{
				co.Open();
				mycommand.CommandText = "Delete from billing where Nama ='"+nama.Text+"'";
				myadapter.SelectCommand = mycommand;
				if (mycommand.ExecuteNonQuery()==1){
					MessageBox.Show("Data berhasil di hapus","Informasi",MessageBoxButtons.OK,MessageBoxIcon.Information);
					readdata();
				}
				co.Close();
			}
			catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}
		}
		
		
		
		void DataGridViewContentClick(object sender, DataGridViewCellEventArgs e)
		{
			nama.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
			com.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
			paket.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
			cuan.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
			
		}
		
		void BtnTambahClick(object sender, EventArgs e)
		{
			InsertData();
		}
		
		void BtnUbahClick(object sender, EventArgs e)
		{
			updateData();
		}
		
		void BtnHapusClick(object sender, EventArgs e)
		{
			deleteData();
		}
		
	}
}
